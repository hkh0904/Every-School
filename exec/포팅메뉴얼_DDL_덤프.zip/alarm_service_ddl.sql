create table alarm
(
    alarm_id           bigint auto_increment comment '알림 PK'
        primary key,
    alarm_master_id    bigint                               not null comment '알림 마스터 FK',
    recipient_id       bigint                               not null comment '수령인 ID',
    is_read            tinyint(1) default 0                 not null comment '읽음 여부',
    is_deleted         tinyint(1) default 0                 not null,
    created_date       timestamp  default CURRENT_TIMESTAMP not null,
    last_modified_date timestamp  default CURRENT_TIMESTAMP not null,
    constraint alarm_ibfk_1
        foreign key (alarm_master_id) references alarm_master (alarm_master_id)
);


create table alarm_master
(
    alarm_master_id    bigint auto_increment comment '알림 마스터 PK'
        primary key,
    sender_id          bigint                               null comment '보낸 사람 FK',
    title              varchar(50)                          not null comment '알림 제목',
    content            varchar(100)                         not null comment '알림 내용',
    school_year        int                                  not null comment '학년도',
    is_deleted         tinyint(1) default 0                 not null,
    created_date       timestamp  default CURRENT_TIMESTAMP not null,
    last_modified_date timestamp  default CURRENT_TIMESTAMP not null,
    type               char                                 not null comment '알림 종류'
);