create table consult
(
    consult_id         bigint       not null primary key auto_increment,
    consult_date_time  datetime     not null,
    message            varchar(500) not null,
    result_content      text         null     default null,
    rejected_reason    varchar(50)  null     default null,
    parent_title       varchar(100) not null,
    teacher_title      varchar(100) not null,
    school_year        integer      not null,
    progress_status_id integer      not null,
    type_id            integer      not null,
    school_id          integer      not null,
    parent_id          integer      not null,
    student_id         integer      not null,
    teacher_id         integer      not null,
    is_deleted         boolean      not null default false,
    created_date       datetime     not null default now(),
    last_modified_date datetime     not null default now()
) default character set utf8
  collate utf8_general_ci;