create table school_class
(
    school_class_id    bigint   not null primary key auto_increment,
    school_id          bigint   not null,
    teacher_id         bigint   not null,
    school_year        integer  not null,
    grade              integer  not null,
    class_num          integer  not null,
    is_deleted         boolean  not null default false,
    created_date       datetime not null default now(),
    last_modified_date datetime not null default now(),
    foreign key (school_id) references school (school_id)
) default character set utf8
  collate utf8_general_ci;

create table school_user
(
    school_user_id     bigint      not null primary key auto_increment,
    school_id          bigint      not null,
    school_class_id    bigint      null,
    user_type_id       integer     not null,
    user_id            bigint      not null,
    school_year        integer     not null,
    student_number     integer     null,
    user_name          varchar(20) not null,
    is_deleted         boolean     not null default false,
    created_date       datetime    not null default now(),
    last_modified_date datetime    not null default now(),
    foreign key (school_id) references school (school_id),
    foreign key (school_class_id) references school_class (school_class_id)
) default character set utf8
  collate utf8_general_ci;