create table report
(
    report_id          bigint       not null primary key auto_increment,
    title              varchar(100) not null,
    description        varchar(500) not null,
    report_who         varchar(100) not null,
    report_when        varchar(100) not null,
    report_where       varchar(100) not null,
    report_what        varchar(100) not null,
    report_how         varchar(100) not null,
    report_why         varchar(100) not null,
    result             varchar(500) null     default null,
    progress_status_id integer      not null default 7001,
    school_year        integer      not null,
    type_id            integer      not null,
    school_id          bigint       not null,
    user_id            bigint       not null,
    is_deleted         boolean      not null default false,
    created_date       datetime     not null default now(),
    last_modified_date datetime     not null default now()
) default character set utf8
  collate utf8_general_ci;