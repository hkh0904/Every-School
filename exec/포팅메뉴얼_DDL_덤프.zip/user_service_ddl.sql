use user_service;

-- code group table
drop table if exists code_group;

create table code_group
(
    group_id           bigint      not null primary key auto_increment,
    group_name         varchar(10) not null,
    is_deleted         boolean     not null default false,
    created_date       timestamp   not null default now(),
    last_modified_date timestamp   not null default now()
) default character set utf8
  collate utf8_general_ci;

-- code detail table
drop table if exists code_detail;

create table code_detail
(
    code_id            bigint      not null primary key auto_increment,
    code_name          varchar(10) not null,
    is_deleted         boolean     not null default false,
    created_date       timestamp   not null default now(),
    last_modified_date timestamp   not null default now(),
    group_id           bigint      not null,
    foreign key (group_id) references code_group (group_id)
) default character set utf8
  collate utf8_general_ci;

drop table if exists user;
create table `user`
(
    user_id            bigint       not null primary key auto_increment,
    dtype              char(1)   not null,
    birth              varchar(10)  not null,
    email              varchar(100) not null,
    name               varchar(20)  not null,
    pwd                varchar(60)  not null,
    user_code_id       integer      not null,
    user_key           varchar(36)  not null,
    is_deleted         boolean      not null default false,
    created_date       timestamp    not null default now(),
    last_modified_date timestamp    not null default now()
) default character set utf8
  collate utf8_general_ci;

drop table if exists parent;
create table parent
(
    user_id     bigint     not null primary key,
    parent_type char(1) not null
) default character set utf8
  collate utf8_general_ci;

drop table if exists student;
create table student
(
    user_id         bigint not null primary key,
    school_class_id bigint
) default character set utf8
  collate utf8_general_ci;

drop table if exists student_parent;
create table student_parent
(
    parent_id          bigint    not null,
    student_id         bigint    not null,
    is_deleted         boolean   not null default false,
    created_date       timestamp not null default now(),
    last_modified_date timestamp not null default now(),
    primary key (parent_id, student_id)
) default character set utf8
  collate utf8_general_ci;