create table do_not_disturb
(
    do_not_disturb_id  bigint auto_increment comment '방해 금지 모드 ID'
        primary key,
    teacher_id         bigint                               not null comment '선생님 ID',
    start_time         timestamp                            not null comment '시작 시간',
    end_time           timestamp                            not null comment '종료 시간',
    is_activate        tinyint(1)                           null,
    is_deleted         tinyint(1) default 0                 not null comment '활성화 여부',
    created_date       timestamp  default CURRENT_TIMESTAMP not null,
    last_modified_date timestamp  default CURRENT_TIMESTAMP not null
);

create table user_call
(
    user_call_id       bigint auto_increment comment '전화 기록 Id'
        primary key,
    other_user_id      bigint                               not null comment '다른 유저 ID',
    teacher_id         bigint                               not null comment '선생님 ID',
    sender             char                                 not null comment '전화건 사람 Type',
    sender_name        varchar(20)                          not null comment '전화건 사람 이름',
    receiver_name      varchar(20)                          not null comment '전화 받는 사람 이름',
    receive_call       char                                 null,
    start_date_time    timestamp                            null comment '전화 시작 시간',
    end_date_time      timestamp                            null comment '전화 종료 시간',
    sentiment          varchar(50)                          null comment '전체 적인 감정 분석',
    neutral            float                                null comment '중립 척도',
    positive           float                                null comment '긍정 척도',
    negative           float                                null comment '부정 척도',
    is_bad             tinyint(1)                           null comment '악성 민원 여부',
    is_deleted         tinyint(1) default 0                 not null,
    created_date       timestamp  default CURRENT_TIMESTAMP not null,
    last_modified_date timestamp  default CURRENT_TIMESTAMP not null
);

create table user_call_details
(
    user_call_details_id bigint auto_increment comment '세부 통화 내역 ID'
        primary key,
    user_call_id         bigint                               not null,
    content              varchar(50)                          not null comment '문제된 사유',
    start                int                                  null comment '문장 시작 시점',
    length               int                                  null comment '문장 길이',
    sentiment            varchar(50)                          null comment '해당 문맥 감정 분석',
    neutral              float                                null comment '중립 척도',
    positive             float                                null comment '긍정 척도',
    negative             float                                null comment '부정 척도',
    is_deleted           tinyint(1) default 0                 not null,
    created_date         timestamp  default CURRENT_TIMESTAMP not null,
    last_modified_date   timestamp  default CURRENT_TIMESTAMP not null,
    file_name            varchar(200)                         null,
    constraint user_call_details_ibfk_1
        foreign key (user_call_id) references user_call (user_call_id)
);