create table chat_room
(
    chat_room_id       bigint    not null auto_increment primary key comment '채팅방 Id',
    is_deleted         boolean   not null default false,
    created_date       timestamp not null default now(),
    last_modified_date timestamp not null default now()
);

create table chat_room_user
(
    chat_room_user_id  bigint      not null auto_increment primary key comment '채팅방 회원 Id',
    chat_room_id       bigint      not null,
    chat_room_title    varchar(50) not null comment '채팅방 제목',
    socket_topic       varchar(20) not null comment '소켓 구독 토픽',
    user_id            bigint      not null comment '회원 Id',
    is_alarm           boolean     not null default true comment '알림 수신 여부',
    unread_count       int         not null default 0 comment '안 읽은 채팅 수',
    last_content       varchar(50) null comment '마지막 채팅 내용',
    is_deleted         boolean     not null default false,
    created_date       timestamp   not null default now(),
    last_modified_date timestamp   not null default now(),
    foreign key (chat_room_id) references chat_room (chat_room_id)
);

create table reason
(
    reason_id          bigint      not null auto_increment primary key comment '필터 사유 Id',
    chat_id            bigint      not null,
    filter_reason      varchar(50) null comment '필터링 이유',
    is_deleted         boolean     not null default false,
    created_date       timestamp   not null default now(),
    last_modified_date timestamp   not null default now()
);

create table chat_review
(
    chat_review_id     bigint      not null auto_increment primary key comment '채팅 검토 Id',
    chat_room_id       bigint      not null,
    title              varchar(50) not null comment '누구와 누구의 대화인가',
    chat_date          timestamp   not null,
    is_deleted         boolean     not null default false,
    created_date       timestamp   not null default now(),
    last_modified_date timestamp   not null default now(),
    foreign key (chat_room_id) references chat_room (chat_room_id)
);